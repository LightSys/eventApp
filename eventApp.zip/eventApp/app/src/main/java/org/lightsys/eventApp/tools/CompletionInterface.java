package org.lightsys.eventApp.tools;

/**
 * Created by gbeeley on 2/27/18.
 */

public interface CompletionInterface {
    void onCompletion();
}
